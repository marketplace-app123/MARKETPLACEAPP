import { Link } from "expo-router";
import { View, Text, Pressable, ScrollView } from "react-native";
import { CATEGORIES, LOGIN_URL } from "../constants";

export default function Home() {
  return (
    <ScrollView contentContainerStyle={{ padding: 16, backgroundColor: "#f6f7fb" }}>
      <Text style={{ fontSize: 22, fontWeight: "700", marginBottom: 12 }}>Eventi e Fiere • Marketplace</Text>
      <View style={{
        flexDirection: "row",
        flexWrap: "wrap",
        justifyContent: "space-between"
      }}>
        {CATEGORIES.map(cat => (
          <Link key={cat.id} href={{ pathname: "/web", params: { url: cat.url, title: cat.title } }} asChild>
            <Pressable style={{ width: "48%", backgroundColor: "#fff", borderRadius: 16, paddingVertical: 18, paddingHorizontal: 12, marginBottom: 12, alignItems: "center", shadowColor: "#000", shadowOpacity: 0.06, shadowRadius: 6 }}>
              <Text style={{ fontSize: 34 }}>{cat.emoji}</Text>
              <Text style={{ marginTop: 8, fontWeight: "600" }}>{cat.title}</Text>
            </Pressable>
          </Link>
        ))}
      </View>

      <Link href={{ pathname: "/web", params: { url: LOGIN_URL, title: "Login" } }} asChild>
        <Pressable style={{ backgroundColor: "#111", borderRadius: 14, padding: 14, marginTop: 8 }}>
          <Text style={{ color: "#fff", textAlign: "center", fontWeight: "600" }}>Accedi / Registrati</Text>
        </Pressable>
      </Link>

      <Text style={{ marginTop: 16, color: "#666" }}>
        Suggerimento: puoi cambiare le URL in <Text style={{ fontWeight: "700" }}>constants.ts</Text> per puntare al tuo marketplace.
      </Text>
    </ScrollView>
  );
}
