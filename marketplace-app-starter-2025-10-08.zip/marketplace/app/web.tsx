import { useLocalSearchParams } from "expo-router";
import { View, ActivityIndicator } from "react-native";
import { WebView } from "react-native-webview";
import { useEffect } from "react";
import { useNavigation } from "expo-router";

export default function WebScreen() {
  const { url, title } = useLocalSearchParams<{ url: string; title?: string }>();
  const navigation = useNavigation();

  useEffect(() => {
    if (title) {
      navigation.setOptions({ title: String(title) });
    }
  }, [title]);

  if (!url) return null;

  return (
    <View style={{ flex: 1 }}>
      <WebView
        source={{ uri: String(url) }}
        startInLoadingState
        renderLoading={() => (
          <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
            <ActivityIndicator />
          </View>
        )}
      />
    </View>
  );
}
