export const LOGIN_URL = "https://www.eventiefiere.com/login"; // cambia se necessario
export const CATEGORIES = [
  { id: "motori", title: "Motori", emoji: "🚗", url: "https://www.eventiefiere.com/categoria/motori" },
  { id: "market", title: "Market", emoji: "🛒", url: "https://www.eventiefiere.com/categoria/market" },
  { id: "immobili", title: "Immobili", emoji: "🏠", url: "https://www.eventiefiere.com/categoria/immobili" },
  { id: "lavoro", title: "Lavoro", emoji: "💼", url: "https://www.eventiefiere.com/categoria/lavoro" },
  { id: "regalo", title: "Regalo", emoji: "🎁", url: "https://www.eventiefiere.com/categoria/regalo" }
];
